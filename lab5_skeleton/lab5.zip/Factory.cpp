#include "Factory.h"

Factory::Factory(int cap) : capacity(cap), count(0) {
    vehicles = new Vehicle*[capacity];
}

Factory::~Factory() {
    for (int i = 0; i < count; i++) {
        delete vehicles[i];
    }
    delete[] vehicles;
}

void Factory::addVehicle(Vehicle* vehicle) {
    // To do3: Implement the addVehicle function
    if (count < capacity) {
        // Check if array is full
        // Add vehicle to array
        vehicles[count++] = vehicle;
    } else {
        cout << "Factory is full, cannot add more vehicles!" << endl;
    }
}

void Factory::listAllVehicles() const {
// To do3: Implement the listAllVehicles function
    for (int i = 0; i < count; i++) {
        // Vehicle *vehicle = vehicles[i];
        vehicles[i]->displayInfo();
    }
}

void Factory::listCombustionVehicles() const {
// To do3: Implement the listCombustionVehicles function
    for (int i = 0; i < count; i++) {
        // cout << typeid(*vehicles[i]).name() << endl;
        // cout << typeid(CombustionVehicle).name() << endl;
        if (typeid(*vehicles[i]).name() == typeid(CombustionVehicle).name()) {
            vehicles[i]->displayInfo();
        }
    }
}

void Factory::listElectricVehicles() const {
// To do3: Implement the listElectricVehicles function
    for (int i = 0; i < count; i++) {
        if (typeid(*vehicles[i]).name() == typeid(ElectricVehicle).name()) {
            vehicles[i]->displayInfo();
        }
    }
}

double Factory::calculateTotalCombustionCost() const {
// Todo4: Implement the calculateTotalConsumption function
    double totalCost = 0.0;
    for (int i = 0; i < count; i++) {
        if (typeid(*vehicles[i]).name() == typeid(CombustionVehicle).name()) {
            totalCost += vehicles[i]->calculateCost();
        }
    }
    return totalCost;
}

double Factory::calculateTotalElectricCost() const {
// Todo3: Implement the calculateTotalElectricCost function
    double totalCost = 0.0;
    for (int i = 0; i < count; i++) {
        if (typeid(*vehicles[i]).name() == typeid(ElectricVehicle).name()) {
            totalCost += vehicles[i]->calculateCost();
        }
    }
    return totalCost;
}

double Factory::calculateTotalCost() const {
// Todo3: Implement the calculateTotalCost function
    double totalCost = 0.0;
    for (int i = 0; i < count; i++) {
        totalCost += vehicles[i]->calculateCost();
    }
    return totalCost;
} 